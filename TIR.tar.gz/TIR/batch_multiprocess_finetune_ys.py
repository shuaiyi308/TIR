

import subprocess as cmd
import sys
from multiprocessing import Process, Queue
import time
import numpy as np
import sys

#time.sleep(8 * 3600)
process_per_gpu = 4

#cmd_reg = "nohup python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -dataset %s -n_shot 5 > imgtextdot_lowmeans_91011layermasktop5_beforeattention_testwithoutdrop_scale4_clip_%s.log 2>&1&"

#cmd_reg = "nohup python3 coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -n_shot 5  -visual_attn_drop_rate 0.2 -text_attn_drop_rate 0.1 -aux_param 7 -aux_param2 8  > attndropv20t10_v7concatt8clip_%s.log 2>&1&"
#cmd_reg = "nohup python3 coop_lora_trainer_siglip_oursaug.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -pos_rate 0 -n_shot 5 -beta_a 0.1 -beta_b 0.1 -droplayer 10 -mask_ratio 0.70 -mask_ratio_small 0.8   --use_patch_dropout --temper_weight 0.5 -encoder vision -aug > ours_siglip_5shot_clips_%s.log 2>&1&"
cmd_reg = "nohup python3 coop_lora_trainer_siglip_pe_our.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -pos_rate 0 -n_shot 1 -beta_a 0.1 -beta_b 0.1 -droplayer 10 -mask_ratio 0.70 -mask_ratio_small 0.8  -encoder vision -aug > baseline_our_pe_1shot_clips_%s.log 2>&1&"
#cmd_reg = "nohup python3 coop_trainer.py  -dataset %s  -n_shot 5 -droplayer 10 -mask_ratio 0.70 -mask_ratio_small 0.8 -aug > ours_coop_layer10_aug_clips_%s.log 2>&1&"

#cmd_reg = "nohup python3 coop_lora_trainer_attentionrecalibration.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -pos_rate 0 -n_shot 5 -beta_a 0.1 -beta_b 0.1 -droplayer 10 -mask_ratio 0.70 -mask_ratio_small 0.8  --use_paint --paint_strength 0.3 --paint_local_ratio 0.15 --paint_warmup_epochs 5 --num_registers 4> baseline_sparc_attentionrecalibration_test_clips_%s.log 2>&1&"
#cmd_reg = "nohup python3 coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -n_shot 5  -visual_attn_drop_rate 0.2 -text_attn_drop_rate 0.1  -aux_param 7 -aux_param2 8 > attndropv20t10_clip_%s.log 2>&1&"

#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -dataset %s -n_shot 5"
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-3 -coop_lr 2e-2 -dataset %s -n_shot 5 -ckp_path output/checkpoints/source_train_coop=lr2e-5_lora=lr2e-6_again/best_%s_model.tar -aux_param 9999"
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -dataset %s -n_shot 5 -ckp_path output/checkpoints/source_train_coop=lr2e-5_lora=lr2e-6_trainTxtLora+Ctx/best_%s_model.tar -aux_param 9999"
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -dataset %s -n_shot 5 -ckp_path output/checkpoints/source_train_coop=lr2e-5_lora=lr2e-6_trainCtx+VisionLora/best_%s_model.tar -aux_param 9999"
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -dataset %s -n_shot 5 -ckp_path output/checkpoints/source_train_coop=lr2e-5_lora=lr2e-6_txtAsDeepPrompt_lr1e-3/best_ave_model.tar -aux_param 10"
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -n_shot 5 -visual_attn_drop_rate 0.2 -aux_param 7 -aux_param2 " + sys.argv[2]
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -n_shot 5 -visual_attn_drop_rate " + sys.argv[2] + " -aux_param 7 -aux_param2 6"
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -n_shot 5 -visual_attn_drop_rate " + sys.argv[2] + " -aux_param 7 -aux_param2 0"
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -n_shot 5 -visual_attn_drop_rate " + sys.argv[2] + " -aux_param2 6"
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -n_shot 5 -visual_attn_drop_rate 0.3 -aux_param2 7 -aux_param " + sys.argv[2]
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -n_shot 5 -aux_param 0 -aux_param2 " + sys.argv[2]
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.01 -dataset %s -n_shot 5 -aux_param " + sys.argv[2]
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -dataset %s -n_shot 5 -aux_param 9 -base_lr " + sys.argv[2]
#**cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -n_shot 5 -aux_param 9999 -visual_attn_drop_rate 0.2 -aux_param2 " + sys.argv[2]
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -n_shot 5 -aux_param 9999 -visual_attn_drop_rate 0.2 -text_attn_drop_rate " + sys.argv[2]
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -n_shot 5 -aux_param 7 -aux_param2 8 -text_attn_drop_rate 0.0 -visual_attn_drop_rate " + sys.argv[2]
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -dataset %s -n_shot 5 -aux_param 7 -aux_param2 " + sys.argv[2] + " -base_lr " + sys.argv[3]
#cmd_reg = "python coop_lora_trainer.py -r 16 -alpha 8 -lora_lr 2e-4 -coop_lr 2e-3 -base_lr 0.001 -dataset %s -n_shot 1 -aug -aux_param " + sys.argv[2]

params = [ 'ISIC','ChestX','CropDiseases', 'EuroSAT']#['ISIC', 'ChestX','CropDiseases', 'EuroSAT'] #'miniImagenet', 
#params = [ 'miniImagenet']
cmd_strs = []
for p in params:
    #cmd_str = cmd_reg%(str(p))
    cmd_str = cmd_reg%(str(p), str(p))
    cmd_strs.append(cmd_str)

def process_run(cmd_strs, gpu_id, queue):
    for cmd_str in cmd_strs:
        start_time = time.time()
        #cmd_str += ' -gpu %d'%gpu_id
        cmd_str = 'CUDA_VISIBLE_DEVICES=%d '%gpu_id + cmd_str
        print('executing "%s" ...'%(cmd_str))
        output = cmd.getoutput(cmd_str)
        acc = float(output.split('\n')[-1].split('Acc = ')[-1].split('%')[0])
        #time.sleep(5)
        #print('"%s" ended, time: %s'%(cmd_str, str(time.time() - start_time)))
        print('%s, time: %s'%(output.split('\n')[-1], str(time.time() - start_time)))
        queue.put(acc)

gpus = [int(gpu_id) for gpu_id in sys.argv[1].split(',')]
total_gpus = []
for i in range(process_per_gpu):
    total_gpus += gpus
gpus = total_gpus

sub_cmd_strs = []
for i in range(len(gpus)):
    sub_cmd_strs.append([])

for i,cmd_str in enumerate(cmd_strs):
    sub_cmd_strs[i%len(gpus)].append(cmd_str)

pool = []; queue = Queue()
for i,gpu in enumerate(gpus):
    p = Process(target=process_run, args=(sub_cmd_strs[i], gpu, queue,))
    p.start()
    pool.append(p)

for p in pool:
    p.join()

accs = []
while not queue.empty():
    accs.append(queue.get())
print('avg acc: ', np.mean(accs))



