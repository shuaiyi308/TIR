# This code is modified from https://github.com/facebookresearch/low-shot-shrink-hallucinate
import json
import torch
import random
from PIL import Image
import torchvision.transforms as transforms
import data.additional_transforms as add_transforms
from data.dataset_aug import SimpleDataset, SetDataset, MultiSetDataset, EpisodicBatchSampler, MultiEpisodicBatchSampler
from abc import abstractmethod

class TransformLoader:
    def __init__(self, image_size,
            normalize_param = dict(mean=[0.48145466, 0.4578275, 0.40821073], std=[0.26862954, 0.26130258, 0.27577711]),
            jitter_param = dict(Brightness=0.4, Contrast=0.4, Color=0.4)):
        self.image_size = image_size
        self.normalize_param = normalize_param
        self.jitter_param = jitter_param

    def parse_transform(self, transform_type):
        if transform_type=='ImageJitter':
            method = add_transforms.ImageJitter( self.jitter_param )
            return method
        method = getattr(transforms, transform_type)

        if transform_type=='RandomResizedCrop':
            return method(self.image_size)
        elif transform_type=='CenterCrop':
            return method(self.image_size)
        # elif transform_type=='Resize':
        #     return method([int(self.image_size*1.15), int(self.image_size*1.15)])
        elif transform_type=='Normalize':
            return method(**self.normalize_param )
        elif transform_type == 'RandomRotation':
            return method(45)
        elif transform_type == 'Resize':
            return method([int(self.image_size), int(self.image_size)])
        else:
            return method()

    def get_composed_transform(self, aug = False):
        if aug:
            transform_list = [['Resize', 'ToTensor', 'Normalize'],
                              ['Resize', 'RandomRotation', 'ImageJitter', 'RandomHorizontalFlip', 'ToTensor', 'Normalize'],
                              ['Resize', 'RandomRotation', 'ToTensor', 'Normalize'],
                              ['Resize', 'ImageJitter', 'ToTensor', 'Normalize'],
                              ['Resize', 'RandomHorizontalFlip', 'ToTensor', 'Normalize']
                              ]
            transform = []
            for i in range(len(transform_list)):
                transform_funcs = [self.parse_transform(x) for x in transform_list[i]]
                transform.append(transforms.Compose(transform_funcs))
        else:
            transform_list = ['Resize', 'CenterCrop', 'ToTensor', 'Normalize']
            transform_funcs = [self.parse_transform(x) for x in transform_list]
            transform = transforms.Compose(transform_funcs)

        return transform

class DataManager:
    @abstractmethod
    def get_data_loader(self, data_file, aug):
        pass

class SimpleDataManager(DataManager):
    def __init__(self, image_size, batch_size):
        super(SimpleDataManager, self).__init__()
        self.batch_size = batch_size
        self.trans_loader = TransformLoader(image_size)

    def get_data_loader(self, data_file, aug): #parameters that would change on train/val set
        transform = self.trans_loader.get_composed_transform(aug)
        dataset = SimpleDataset(data_file, transform)
        data_loader_params = dict(batch_size = self.batch_size, shuffle = True, num_workers = 8, pin_memory = True)
        data_loader = torch.utils.data.DataLoader(dataset, **data_loader_params)

        return data_loader


#################################
#################################
class SetDataManager(DataManager):
    def __init__(self, image_size, n_way, n_support, n_query, n_eposide=100):
        super(SetDataManager, self).__init__()
        self.image_size = image_size
        self.n_way = n_way
        self.batch_size = n_support + n_query
        self.n_eposide = n_eposide

        self.trans_loader = TransformLoader(image_size)

    def get_data_loader(self, data_file, aug): #parameters that would change on train/val set
        transform = self.trans_loader.get_composed_transform(aug)
        if isinstance(data_file, list):
            dataset = MultiSetDataset( data_file , self.batch_size, transform )
            sampler = MultiEpisodicBatchSampler(dataset.lens(), self.n_way, self.n_eposide )
        else:
            dataset = SetDataset( data_file , self.batch_size, transform )
            sampler = EpisodicBatchSampler(len(dataset), self.n_way, self.n_eposide )
        data_loader_params = dict(batch_sampler = sampler,  num_workers=8)
        data_loader = torch.utils.data.DataLoader(dataset, **data_loader_params)
        return data_loader
#################################
#################################
